package com.exambuilder;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Exam {

    private final StringProperty title;
    private final IntegerProperty timeLimit;
    private final IntegerProperty questionCount;

    public Exam(String title, int timeLimit, int questionCount) {
        this.title = new SimpleStringProperty(title);
        this.timeLimit = new SimpleIntegerProperty(timeLimit);
        this.questionCount = new SimpleIntegerProperty(questionCount);
    }

    public StringProperty titleProperty() {
        return title;
    }

    public IntegerProperty timeLimitProperty() {
        return timeLimit;
    }

    public IntegerProperty questionCountProperty() {
        return questionCount;
    }

    public String getTitle() {
        return title.get();
    }

    public int getTimeLimit() {
        return timeLimit.get();
    }

    public int getQuestionCount() {
        return questionCount.get();
    }
}
