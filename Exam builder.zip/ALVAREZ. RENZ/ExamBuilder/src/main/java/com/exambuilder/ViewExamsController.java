package com.exambuilder;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.util.List;
import javafx.fxml.FXMLLoader;
public class ViewExamsController {

    @FXML
    private TableView<Exam> examsTable;
    @FXML
    private TableColumn<Exam, String> examTitleColumn;
    @FXML
    private TableColumn<Exam, Integer> timeLimitColumn;
    @FXML
    private TableColumn<Exam, Integer> questionCountColumn;

    private List<Exam> examList; // This should be fetched from the database

    @FXML
    public void initialize() {
        // Initialize columns
        examTitleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());
        timeLimitColumn.setCellValueFactory(cellData -> cellData.getValue().timeLimitProperty().asObject());
        questionCountColumn.setCellValueFactory(cellData -> cellData.getValue().questionCountProperty().asObject());

        // Fetch the exam list (for now, using dummy data)
        loadExamData();
    }

    private void loadExamData() {
        // Dummy data for now
        examList = List.of(
                new Exam("Math Exam", 60, 10),
                new Exam("Science Exam", 45, 8),
                new Exam("History Exam", 50, 12)
        );

        examsTable.getItems().setAll(examList);
    }

    @FXML
    private Button backToDashboardButton;

    @FXML
    private void handleBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("teacher_dashboard.fxml")); // Make sure this file name matches your actual FXML
            Scene scene = new Scene(loader.load(), 800, 600);
            Stage stage = (Stage) backToDashboardButton.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}