package com.exambuilder;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
    public Connection getConnection() {
        Connection conn = null;
        try {
            String url = "jdbc:mysql://localhost:3306/exambuilder"; // Replace with your DB name
            String user = "root"; // Replace with your DB username
            String password = "Renzalv@1"; // Replace with your DB password

            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }
}
