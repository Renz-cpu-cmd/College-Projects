package com.exambuilder;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.event.ActionEvent; // For handling ActionEvents
import javafx.scene.Node; // For accessing the Node from the event

import java.net.URL;
import java.util.*;

public class TakeExam implements Initializable {

    @FXML
    private Label questionLabel;
    @FXML
    private RadioButton option1RadioButton;
    @FXML
    private RadioButton option2RadioButton;
    @FXML
    private RadioButton option3RadioButton;
    @FXML
    private RadioButton option4RadioButton;
    @FXML
    private TextField shortAnswerField;
    @FXML
    private Button nextButton;
    @FXML
    private Button finishButton;  // Add a finish button for completing the exam

    private ToggleGroup optionsGroup;
    private List<Question> questions;
    private List<String> studentAnswers;  // To store student answers
    private int currentQuestionIndex = 0;
    private String examTitle;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        optionsGroup = new ToggleGroup();
        option1RadioButton.setToggleGroup(optionsGroup);
        option2RadioButton.setToggleGroup(optionsGroup);
        option3RadioButton.setToggleGroup(optionsGroup);
        option4RadioButton.setToggleGroup(optionsGroup);

        studentAnswers = new ArrayList<>();  // Initialize the student answers list
        finishButton.setVisible(false);  // Initially hide the finish button
    }

    // Set exam title and load questions based on it
    public void setExamTitle(String title) {
        this.examTitle = title;
        loadDummyQuestions(examTitle);  // Load questions specific to the exam title
        showQuestion();
    }

    // Method to load questions based on the selected exam title
    private void loadDummyQuestions(String examTitle) {
        questions = new ArrayList<>();

        // Logic based on exam title
        switch (examTitle.toLowerCase()) {
            case "math exam":
                questions.add(new Question("What is 5 × 6?", Question.Type.MULTIPLE_CHOICE,
                        List.of("25", "30", "35", "20"), "30"));
                questions.add(new Question("What is the square root of 64?", Question.Type.MULTIPLE_CHOICE,
                        List.of("6", "8", "10", "12"), "8"));
                questions.add(new Question("The value of π is exactly 3.14.", Question.Type.TRUE_FALSE,
                        List.of("True", "False"), "False"));
                questions.add(new Question("Define a prime number.", Question.Type.SHORT_ANSWER,
                        null, "A number greater than 1 with only two factors: 1 and itself"));
                break;

            case "science exam":
                questions.add(new Question("What planet is known as the Red Planet?", Question.Type.MULTIPLE_CHOICE,
                        List.of("Earth", "Mars", "Jupiter", "Saturn"), "Mars"));
                questions.add(new Question("What is the chemical formula for water?", Question.Type.MULTIPLE_CHOICE,
                        List.of("H2O", "CO2", "O2", "CH4"), "H2O"));
                questions.add(new Question("Water boils at 100°C.", Question.Type.TRUE_FALSE,
                        List.of("True", "False"), "True"));
                questions.add(new Question("What is photosynthesis?", Question.Type.SHORT_ANSWER,
                        null, "The process by which green plants make food using sunlight"));
                break;

            case "history exam":
                questions.add(new Question("Who was the first President of the USA?", Question.Type.MULTIPLE_CHOICE,
                        List.of("George Washington", "Abraham Lincoln", "John Adams", "Thomas Jefferson"), "George Washington"));
                questions.add(new Question("The Great Wall of China was built in one year.", Question.Type.TRUE_FALSE,
                        List.of("True", "False"), "False"));
                questions.add(new Question("What was the Industrial Revolution?", Question.Type.SHORT_ANSWER,
                        null, "A period of rapid industrial growth during the 18th–19th centuries"));
                break;

            default:
                questions.add(new Question("No questions available for this exam.", Question.Type.SHORT_ANSWER,
                        null, ""));
                break;
        }
    }

    private void showQuestion() {
        if (currentQuestionIndex >= questions.size()) {
            questionLabel.setText("Exam Complete!");
            nextButton.setDisable(true);
            finishButton.setVisible(true);  // Show finish button when all questions are answered
            return;
        }

        Question q = questions.get(currentQuestionIndex);
        questionLabel.setText(q.getQuestionText());

        if (q.getType() == Question.Type.MULTIPLE_CHOICE || q.getType() == Question.Type.TRUE_FALSE) {
            showOptions(q.getOptions());
            shortAnswerField.setVisible(false);
        } else { // Short Answer
            hideOptions();
            shortAnswerField.setVisible(true);
            shortAnswerField.clear();
        }
    }

    private void showOptions(List<String> options) {
        option1RadioButton.setText(options.get(0));
        option2RadioButton.setText(options.get(1));
        option3RadioButton.setText(options.size() > 2 ? options.get(2) : "");
        option4RadioButton.setText(options.size() > 3 ? options.get(3) : "");

        option1RadioButton.setVisible(true);
        option2RadioButton.setVisible(true);
        option3RadioButton.setVisible(options.size() > 2);
        option4RadioButton.setVisible(options.size() > 3);
    }

    private void hideOptions() {
        option1RadioButton.setVisible(false);
        option2RadioButton.setVisible(false);
        option3RadioButton.setVisible(false);
        option4RadioButton.setVisible(false);
    }

    @FXML
    private void handleNext() {
        Question q = questions.get(currentQuestionIndex);

        String answer = "";

        if (q.getType() == Question.Type.SHORT_ANSWER) {
            answer = shortAnswerField.getText();
        } else {
            RadioButton selected = (RadioButton) optionsGroup.getSelectedToggle();
            if (selected != null) {
                answer = selected.getText();
            }
        }

        studentAnswers.add(answer);  // Store the student's answer

        currentQuestionIndex++;
        optionsGroup.selectToggle(null);  // Clear selected option
        showQuestion();
    }

    @FXML
    private void handleFinishExam() {
        // Calculate score based on the answers
        int score = calculateScore();

        try {
            // Load the Result Screen
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("result_screen.fxml"));
            Scene resultScene = new Scene(fxmlLoader.load(), 600, 400);
            ResultScreenController controller = fxmlLoader.getController();

            // Pass the questions, studentAnswers, score, and examTitle to the controller
            controller.initialize(questions, studentAnswers, score, examTitle);  // Pass the examTitle here

            Stage stage = (Stage) finishButton.getScene().getWindow();
            stage.setScene(resultScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private int calculateScore() {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (studentAnswers.get(i).equals(questions.get(i).getCorrectAnswer())) {
                score++;
            }
        }
        return score;
    }


}