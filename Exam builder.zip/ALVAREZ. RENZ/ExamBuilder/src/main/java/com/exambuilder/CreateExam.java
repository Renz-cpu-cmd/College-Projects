package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TextField;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.Node;
import java.io.IOException;


public class CreateExam {
    @FXML
    private TextField examTitleField;
    @FXML
    private Spinner<Integer> timeLimitSpinner;
    @FXML
    private Spinner<Integer> totalMarksSpinner;

    @FXML
    private void initialize() {
        // Set up the spinner values for time limit and total marks (example: 1-120 minutes, 1-100 marks)
        timeLimitSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 120, 60));
        totalMarksSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 100, 50));
    }

    @FXML
    private void handleCreateExam(ActionEvent event) {
        String examTitle = examTitleField.getText();
        int timeLimit = timeLimitSpinner.getValue();
        int totalMarks = totalMarksSpinner.getValue();

        if (examTitle.isEmpty()) {
            showAlert(AlertType.ERROR, "Error", "Please provide a valid exam title.");
        } else {
            // Logic to save the exam (not implemented yet)
            System.out.println("Exam Created: " + examTitle);
            System.out.println("Time Limit: " + timeLimit + " minutes");
            System.out.println("Total Marks: " + totalMarks);

            // Show success message
            showAlert(AlertType.INFORMATION, "Success", "Exam created successfully!");

            // Load the Add Questions screen (or you can navigate to another screen here)
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("add_questions.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 500, 400);
                Stage stage = (Stage) examTitleField.getScene().getWindow();
                stage.setScene(scene);
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        try {
            // Load the Teacher Dashboard scene
            FXMLLoader loader = new FXMLLoader(getClass().getResource("teacher_dashboard.fxml"));
            Scene dashboardScene = new Scene(loader.load(), 800, 600);  // Adjust the size as needed
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
