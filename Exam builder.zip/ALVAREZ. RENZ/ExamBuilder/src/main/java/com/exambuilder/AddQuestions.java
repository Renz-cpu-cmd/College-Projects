package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.Node;
import java.io.IOException;

public class AddQuestions {

    @FXML
    private ComboBox<String> questionTypeComboBox;

    @FXML
    private TextField questionTextField;

    @FXML
    private TextField option1Field;

    @FXML
    private TextField option2Field;

    @FXML
    private TextField option3Field;

    @FXML
    private TextField option4Field;

    @FXML
    private TextField correctAnswerField;

    @FXML
    private Spinner<Integer> marksSpinner;

    // Define HBoxes to hold the option fields
    @FXML
    private HBox optionsHBox;

    @FXML
    private void initialize() {
        // Set up the question type combo box
        questionTypeComboBox.getItems().addAll("Multiple Choice", "True/False", "Short Answer");
        questionTypeComboBox.getSelectionModel().selectFirst(); // Default selection

        // Set default marks spinner value
        marksSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 1));

        // Call the method to update visibility based on the selected question type
        updateQuestionFields();
    }

    @FXML
    private void handleQuestionTypeChange() {
        // Update visibility whenever the question type changes
        updateQuestionFields();
    }

    private void updateQuestionFields() {
        String questionType = questionTypeComboBox.getValue();

        // Show or hide fields based on the question type
        if ("Multiple Choice".equals(questionType)) {
            optionsHBox.setVisible(true);
            option1Field.setVisible(true);
            option2Field.setVisible(true);
            option3Field.setVisible(true);
            option4Field.setVisible(true);
        } else {
            optionsHBox.setVisible(false);
            option1Field.setVisible(false);
            option2Field.setVisible(false);
            option3Field.setVisible(false);
            option4Field.setVisible(false);
        }

        // Always show the correct answer field for all question types
        correctAnswerField.setVisible(true);
    }

    @FXML
    private void handleAddQuestion(ActionEvent event) {
        String questionType = questionTypeComboBox.getValue();
        String questionText = questionTextField.getText();
        int marks = marksSpinner.getValue();

        // Validate question text and correct answer field
        if (questionType != null && !questionText.isEmpty()) {
            switch (questionType) {
                case "Multiple Choice":
                    String option1 = option1Field.getText();
                    String option2 = option2Field.getText();
                    String option3 = option3Field.getText();
                    String option4 = option4Field.getText();
                    String correctAnswer = correctAnswerField.getText();

                    // Ensure options are filled
                    if (option1.isEmpty() || option2.isEmpty() || option3.isEmpty() || option4.isEmpty() || correctAnswer.isEmpty()) {
                        showAlert(AlertType.ERROR, "Error", "Please fill in all the fields for Multiple Choice.");
                        return;
                    }

                    System.out.println("Options: " + option1 + ", " + option2 + ", " + option3 + ", " + option4);
                    System.out.println("Correct Answer: " + correctAnswer);
                    break;
                case "True/False":
                    String trueFalseAnswer = correctAnswerField.getText();
                    if (trueFalseAnswer.isEmpty()) {
                        showAlert(AlertType.ERROR, "Error", "Please provide a correct answer for True/False.");
                        return;
                    }
                    System.out.println("Correct Answer: " + trueFalseAnswer);
                    break;
                case "Short Answer":
                    String shortAnswer = correctAnswerField.getText();
                    if (shortAnswer.isEmpty()) {
                        showAlert(AlertType.ERROR, "Error", "Please provide a correct answer for Short Answer.");
                        return;
                    }
                    System.out.println("Correct Answer: " + shortAnswer);
                    break;
            }

            showAlert(AlertType.INFORMATION, "Question Added", "Question has been added successfully!");

            // Clear form fields after adding the question
            clearFormFields();
        } else {
            showAlert(AlertType.ERROR, "Error", "Please fill in all the required fields.");
        }
    }

    private void clearFormFields() {
        // Clear the form fields
        questionTextField.clear();
        option1Field.clear();
        option2Field.clear();
        option3Field.clear();
        option4Field.clear();
        correctAnswerField.clear();
        marksSpinner.getValueFactory().setValue(1);
        questionTypeComboBox.getSelectionModel().selectFirst();
    }

    @FXML
    private void handleBackToDashboard(ActionEvent event) {
        // Ask for confirmation before navigating back to the dashboard
        if (showConfirmationDialog("Are you sure you want to go back to the dashboard? Unsaved questions will be lost.")) {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("teacher_dashboard.fxml"));
                Scene dashboardScene = new Scene(loader.load(), 800, 600);  // Adjust the size as needed
                Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
                stage.setScene(dashboardScene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace(); // Handle exceptions if any
            }
        }
    }

    private boolean showConfirmationDialog(String message) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirmation");
        alert.setHeaderText(message);
        alert.setContentText("Are you sure?");
        return alert.showAndWait().filter(buttonType -> buttonType.getText().equals("OK")).isPresent();
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
