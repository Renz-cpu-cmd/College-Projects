package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
public class TeacherDashboard {
    @FXML
    private Button createExamButton;

    @FXML
    private Button viewExamsButton;

    @FXML
    private Button viewResultsButton;

    @FXML
    private void handleCreateExam(ActionEvent event) {
        try {
            // Load the Create Exam screen
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("create_exam.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 400, 300);

            // Get the current stage from the event (which is the parent of the button clicked)
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();

            // Set the new scene and show the window
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleViewExams() {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("view_exams.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 800, 600);
            Stage stage = (Stage) viewExamsButton.getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @FXML
    private void handleViewResults() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("view_results.fxml"));
            Scene resultScene = new Scene(loader.load(), 800, 600);
            Stage stage = (Stage) viewResultsButton.getScene().getWindow(); // Assuming you have a viewResultsButton
            stage.setScene(resultScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}