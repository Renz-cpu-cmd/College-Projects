package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.CheckBox;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Label;

public class LoginScreen {
    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private CheckBox rememberMeCheckBox;

    @FXML
    private Label welcomeLabel;

    @FXML
    private void initialize() {
        // Set a welcome message
        welcomeLabel.setText("Welcome to Exam Builder!");
    }

    @FXML
    private void handleLogin(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Simple validation for demo purposes
        if (username.equals("teacher") && password.equals("password123")) {
            showAlert(AlertType.INFORMATION, "Login Successful", "Welcome Teacher!");
            loadScene("teacher_dashboard.fxml", "Teacher Dashboard");
        } else if (username.equals("student") && password.equals("password123")) {
            showAlert(AlertType.INFORMATION, "Login Successful", "Welcome Student!");
            loadScene("student_dashboard.fxml", "Student Dashboard");
        } else {
            showAlert(AlertType.ERROR, "Login Failed", "Invalid username or password. Please try again.");
        }
    }

    private void showAlert(AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadScene(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Scene scene = new Scene(loader.load(), 600, 400);
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setTitle(title);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            showAlert(AlertType.ERROR, "Error", "Unable to load: " + fxmlFile);
        }
    }
}
