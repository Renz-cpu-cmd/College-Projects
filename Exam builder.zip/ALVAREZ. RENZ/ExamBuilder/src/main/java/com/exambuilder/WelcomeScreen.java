package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class WelcomeScreen {
    @FXML
    private Button teacherLoginButton;

    @FXML
    private Button studentLoginButton;

    @FXML
    private void handleTeacherLogin(ActionEvent event) {
        try {
            Main.showLoginScreen((Stage) teacherLoginButton.getScene().getWindow());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleStudentLogin(ActionEvent event) {
        try {
            Main.showLoginScreen((Stage) studentLoginButton.getScene().getWindow());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
