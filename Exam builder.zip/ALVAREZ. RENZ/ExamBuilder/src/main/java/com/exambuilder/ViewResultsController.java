package com.exambuilder;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

import java.util.List;

public class ViewResultsController {

    @FXML private ListView<String> resultsListView;
    @FXML private Button backToDashboardButton;

    private List<String> results; // List of results from the database or dummy data

    // Initialize the ListView with the results
    public void initialize() {
        results = loadDummyResults(); // Load dummy results or fetch from the database
        resultsListView.getItems().clear(); // Clear any previous data
        resultsListView.getItems().addAll(results); // Add the results to the ListView
    }

    // Handle the back to dashboard action

    @FXML
    private void handleBackToDashboard() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("teacher_dashboard.fxml")); // <- use the correct FXML here
            Scene dashboardScene = new Scene(loader.load(), 800, 600);
            Stage stage = (Stage) backToDashboardButton.getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }






    // Dummy method to simulate loading results (you can replace this with real database code)
    private List<String> loadDummyResults() {
        return List.of(
                "Math Exam: 90/100 - Passed",
                "Science Exam: 80/100 - Passed",
                "History Exam: 60/100 - Failed"
        );
    }
}
