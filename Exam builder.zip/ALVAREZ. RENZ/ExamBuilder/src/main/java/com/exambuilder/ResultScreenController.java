package com.exambuilder;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

import java.util.List;

public class ResultScreenController {

    @FXML private Label scoreLabel;
    @FXML private ListView<String> answerListView;
    @FXML private Button backToDashboardButton;
    @FXML private Button retakeExamButton;

    private List<Question> questions;
    private List<String> studentAnswers;
    private String examTitle;

    // Method to initialize the result screen with the score and answers
    public void initialize(List<Question> questions, List<String> studentAnswers, int score, String examTitle) {
        this.questions = questions;
        this.studentAnswers = studentAnswers;
        this.examTitle = examTitle;

        // Display score
        scoreLabel.setText("Your Score: " + score);

        // Show answers
        answerListView.getItems().clear();
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            String answerStatus = studentAnswers.get(i).equals(question.getCorrectAnswer()) ? "Correct" : "Incorrect";
            String displayText = question.getQuestionText() + "\nYour Answer: " + studentAnswers.get(i) +
                    " (" + answerStatus + ")";
            answerListView.getItems().add(displayText);
        }
    }

    @FXML
    private void handleBackToDashboard() {
        try {
            // Correct FXML path, make sure the dashboard.fxml is in the correct location
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/exambuilder/student_dashboard.fxml"));

            // Check if FXML is loaded properly
            if (fxmlLoader.getLocation() == null) {
                throw new Exception("FXML not found at the specified path");
            }

            // Create a new Scene with the loaded FXML
            Scene dashboardScene = new Scene(fxmlLoader.load(), 600, 400);

            // Get the current stage and set the new scene
            Stage stage = (Stage) backToDashboardButton.getScene().getWindow();
            stage.setScene(dashboardScene);
            stage.show();
        } catch (Exception e) {
            // Print the error to the console for debugging
            e.printStackTrace();
            // Optionally, show an alert to the user
            Alert alert = new Alert(Alert.AlertType.ERROR, "Failed to load the dashboard: " + e.getMessage());
            alert.showAndWait();
        }
    }


    @FXML
    private void handleRetakeExam() {
        try {
            // Ensure the correct FXML file with the correct controller
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/exambuilder/take_exam.fxml"));
            // Load the FXML into a new scene
            Scene takeExamScene = new Scene(loader.load(), 800, 600);

            // Get the controller for the TakeExam scene and pass the exam title
            TakeExam takeExamController = loader.getController();
            takeExamController.setExamTitle(examTitle); // Reuse previous exam title

            // Get the current stage and set the new scene
            Stage stage = (Stage) retakeExamButton.getScene().getWindow();
            stage.setScene(takeExamScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
