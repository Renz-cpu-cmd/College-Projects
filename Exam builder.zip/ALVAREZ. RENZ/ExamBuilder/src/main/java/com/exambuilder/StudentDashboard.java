package com.exambuilder;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;

public class StudentDashboard {

    @FXML
    private ListView<String> examListView;

    @FXML
    private Button startExamButton;

    @FXML
    private void initialize() {
        // Populate the ListView with some dummy exam titles (you can fetch this from the database later)
        examListView.getItems().addAll("Math Exam", "Science Exam", "History Exam");

        // Ensure that the Start Exam button is disabled if no exam is selected
        startExamButton.setDisable(true);

        // Listen for selection changes in the ListView
        examListView.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            // Enable or disable the Start Exam button based on whether an item is selected
            startExamButton.setDisable(newValue == null);
        });
    }

    @FXML
    private void handleStartExam(ActionEvent event) {
        String selectedExam = examListView.getSelectionModel().getSelectedItem();

        if (selectedExam != null) {
            System.out.println("Starting the exam: " + selectedExam);

            // Load the Take Exam screen here based on the selected exam
            try {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("take_exam.fxml"));
                Scene scene = new Scene(fxmlLoader.load(), 600, 400);
                Stage stage = (Stage) startExamButton.getScene().getWindow();

                // Get the TakeExam controller from the loader
                TakeExam takeExamController = fxmlLoader.getController();
                takeExamController.setExamTitle(selectedExam);  // Pass the selected exam title to the controller

                stage.setScene(scene);
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("No exam selected.");
        }
    }
}