package com.exambuilder;

import java.util.List;

public class Question {
    public enum Type { MULTIPLE_CHOICE, TRUE_FALSE, SHORT_ANSWER }

    private String questionText;
    private Type type;
    private List<String> options;  // Null for short answer
    private String correctAnswer;

    public Question(String questionText, Type type, List<String> options, String correctAnswer) {
        this.questionText = questionText;
        this.type = type;
        this.options = options;
        this.correctAnswer = correctAnswer;
    }

    public String getQuestionText() {
        return questionText;
    }

    public Type getType() {
        return type;
    }

    public List<String> getOptions() {
        return options;
    }

    public String getCorrectAnswer() {
        return correctAnswer;
    }
}
